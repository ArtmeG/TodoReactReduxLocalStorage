import {CHANGE_FILTER} from "../constans";

const tabReducer = (state = 'all', {type, mode}) => {
  switch (type) {
    case CHANGE_FILTER:
      return mode;
    default: return state;
  }
}

export default tabReducer;