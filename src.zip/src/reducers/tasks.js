import { ADD_TASK, COMPLETE_TASK, REMOVE_TASK, INIT_TASKS } from '../constans';

const tasks = (state = [], {type, ...action}) => {
  switch (type) {
    case INIT_TASKS:
      return action.tasks;

    case ADD_TASK:
      const {id, taskText, isCompleted} = action;
      return [
        ...state,
        {
          id,
          taskText,
          isCompleted
        }
      ];

    case REMOVE_TASK:
      return [...state].filter(task => task?.id !== +action.id);

    case COMPLETE_TASK:
      return [...state].map(task => {
        if (task.id === +action.id) {
          task.isCompleted = !task.isCompleted;
        }
        return task;
      });

    default: return state;
  }
}

export default tasks;