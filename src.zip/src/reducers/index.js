import {combineReducers} from "redux";
import tasks from "./tasks";
import tabReducer from "./tab";

const rootReducer = combineReducers({
  tasks,
  mode: tabReducer
})

export default rootReducer;