import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Main from './container/main/Main';
import {Provider} from 'react-redux'
import store from './store';

ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <Main/>
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);

