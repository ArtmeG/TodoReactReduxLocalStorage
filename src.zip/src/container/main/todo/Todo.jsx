import React, { Component } from 'react';
import { connect } from 'react-redux';

import { addTask, initTask } from '../../../actions/actionCreator'

import TodoInput from "../../../components/todo-input/TodoInput";
import TodoList from "../../../components/todo-list/TodoList";
import Tabs from "../../../components/tabs/Tabs";

class Todo extends Component {
  state = {
    inputText: ''
  }

  componentDidMount() {
    this.props.initTask();
  }

  onChangeInputHandler = ({target: {value}}) => {
    this.setState({
      inputText: value
    })
  }

  addTask = ({key}) => {
    const { inputText } = this.state;
    if (inputText !== '' && key === 'Enter') {
      const { addTask } = this.props;
      addTask(
        Math.random(),
        inputText,
        false
      );
      this.setState({
        inputText: ''
      });
    }
  }

  render() {
    const { inputText } = this.state;

    return (
      <div className="ui container">
        <TodoInput
          value={inputText}
          onChangeInputHandler={this.onChangeInputHandler}
          onKeyPressInputHandler={this.addTask}
        />
        <Tabs />
        <TodoList />
      </div>
    )
  }
}

export default connect(({tasks}) => ({
  tasks
}),
  {
    addTask,
    initTask
  }
)(Todo);