import React, {Component} from 'react';
import Title from "../../components/title/Title";
import Todo from "./todo/Todo";

class Main extends Component {
  render() {
    return (
      <div className='ui container'>
        <Title title='TODO LIST' />
        <Todo />
      </div>
    )
  }
}

export default Main;