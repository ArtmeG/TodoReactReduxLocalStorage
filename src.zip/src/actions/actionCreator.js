import {ADD_TASK, CHANGE_FILTER, COMPLETE_TASK, INIT_TASKS, REMOVE_TASK} from '../constans'
import { load } from 'redux-localstorage-simple';

export const changeFilter = (mode) => ({
  type: CHANGE_FILTER,
  mode
})

export const addTask = (id, taskText, isCompleted) => ({
  type: ADD_TASK,
  id,
  taskText,
  isCompleted
});

export const removeTask = id => ({
  type: REMOVE_TASK,
  id
});

export const completeTask = id => ({
  type: COMPLETE_TASK,
  id
});

export const initTask = () => {
  let TASKS = load({namespace: 'todo-list'});

  if (!TASKS || !TASKS.tasks) {
    TASKS = {
      tasks: []
    }
  }

  return {
    type: INIT_TASKS,
    tasks: TASKS.tasks
  }
};