import React, {Component} from "react";

class TodoItem extends Component {
  onClickHandler = ({target, currentTarget}) => {
    const {deleteTodoItem, completeTodoItem} = this.props;

    switch (target.dataset.btn) {
      case 'delete':
        deleteTodoItem(currentTarget.id);
        break;
      case 'complete':
        completeTodoItem(currentTarget.id);
        break;
      default: break;
    }
  }

  render() {
    const {
      task: {
        id,
        taskText,
        isCompleted
      }
    } = this.props;

    const completeBtn = isCompleted ? 'Uncomplete' : 'Complete';

    return (
      <li
        id={id}
        onClick={this.onClickHandler}
        className={`ui segment ${isCompleted ? 'complete' : null}`}
      >
        <p>{taskText}</p>
        <button className='ui button red' data-btn='delete'>Delete</button>
        <button className='ui button green' data-btn='complete'>{completeBtn}</button>
      </li>
    )
  }
}

export default TodoItem;