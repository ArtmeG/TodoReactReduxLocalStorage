import React, {Component} from 'react';
import {connect} from "react-redux";
import {changeFilter} from "../../actions/actionCreator";

class Tabs extends Component {
  onClickTabsHandler = ({target}) => {
    const btnAttr = target.dataset.btn;
    if (btnAttr) {
      this.props.changeFilter(btnAttr);
    }
  }

  render() {
    const {mode} = this.props;
    return (
      <div
      onClick={this.onClickTabsHandler}
        className='ui raised segment'
      >
        <button
          data-btn='all'
          className={`ui button ${mode === 'all' ? 'orange' : null}`}
        >
          All
        </button>
        <button
          data-btn='complete'
          className={`ui button ${mode === 'complete' ? 'orange' : null}`}
        >
          Completed
        </button>
        <button
          data-btn='uncomplete'
          className={`ui button ${mode === 'uncomplete' ? 'orange' : null}`}
        >
          UnCompleted
        </button>
      </div>
    )
  }
}

export default connect(({mode}) => {
  return {mode};
  },
  {changeFilter}
)(Tabs);