export const ADD_TASK = 'ADD_TASK';
export const REMOVE_TASK = 'REMOVE_TASK';
export const COMPLETE_TASK = 'COMPLETE_TASK';
export const CHANGE_FILTER = 'CHANGE_FILTER';
export const INIT_TASKS = 'INIT_TASKS';
export const TAB_ALL = 'all';
export const TAB_COMPLETE = 'complete';
export const TAB_UNCOMPLETE = 'uncomplete';